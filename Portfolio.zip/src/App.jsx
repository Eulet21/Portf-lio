import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Portfolio from "./pages/Portfolio";
import Contato from "./pages/Contato";
import Footer from "./Components/Footer";
import "./index.css"; // Estilos globais
import "./app.css"; // Estilos específicos do App

const App = () => (
  <Router>
    <header>
      <nav>
        <ul>
          <li>
            <a href="/">Home</a>
          </li>
          <li>
            <a href="/portfolio">Portfólio</a>
          </li>
          <li>
            <a href="/contato">Contato</a>
          </li>
        </ul>
      </nav>
    </header>
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/portfolio" element={<Portfolio />} />
      <Route path="/contato" element={<Contato />} />
      <Route path="*" element={<h2>Página não encontrada</h2>} />
    </Routes>
    <Footer /> {/* Footer adicionado aqui */}
  </Router>
);

export default App;
