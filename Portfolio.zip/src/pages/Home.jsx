import minhafoto from "../assets/foto.jpeg";

const Home = () => {
  return (
    <div className="home">
      <div className="content">
        <img className="img" src={minhafoto} alt="Foto de Letícia" />
        <h2>Portfólio de Apresentação</h2>
        <div className="desc">
          <p>
            Me chamo Letícia, curso Análise e Desenvolvimento de Sistemas e sou formada em Técnico de Informática e Administração.
            Este portfólio apresenta meus projetos desenvolvidos na Uninassau. Meu objetivo é trabalhar na área e me especializar em Front-End, pois adoro estilizar e criar interfaces.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Home;
