import { useState } from "react";

const Contato = () => {
  // Estado para controlar a exibição da mensagem de sucesso
  const [submitted, setSubmitted] = useState(false);

  // Função para lidar com o envio do formulário
  const handleSubmit = (e) => {
    e.preventDefault(); // Impede o comportamento padrão de envio do formulário
    setSubmitted(true); // Atualiza o estado para mostrar a mensagem de sucesso
  };

  return (
    <div className="contact-info">
      <h1>Entre em Contato</h1>
      <div className="contact-item">
        <strong>Nome:</strong>
        <p>Letícia de Souza Ferreira</p>
      </div>
      <div className="contact-item">
        <strong>Contato:</strong>
        <p>(84) 9 875993-59</p>
      </div>
      <div className="contact-item">
        <strong>GitHub:</strong>
        <p>
          <a
            href="https://github.com/lucasmathcode"
            target="_blank"
            rel="noopener noreferrer"
          >
          
            github.com/Eulet21
          </a>
        </p>
      </div>
      <div className="contact-item">
        <strong>E-mail:</strong>
        <p>
          <a href="leticiadesouzaferreira226gmail.com">leticiadesouzaferreira226gmail.com</a>
        </p>
      </div>

      {/* Formulário de Contato */}
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="name">Nome:</label>
          <input
            type="text"
            id="name"
            name="name"
            placeholder="Digite seu nome"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="email">E-mail:</label>
          <input
            type="email"
            id="email"
            name="email"
            placeholder="Digite seu e-mail"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="message">Mensagem:</label>
          <textarea
            id="message"
            name="message"
            rows="4"
            placeholder="Digite sua mensagem"
            required
          ></textarea>
        </div>
        <button type="submit">Enviar Mensagem</button>
      </form>

      {/* Exibe mensagem após envio */}
      {submitted && (
        <div className="success-message">
          <p>Obrigado! Sua mensagem foi enviada com sucesso.</p>
        </div>
      )}
    </div>
  );
};

export default Contato;
