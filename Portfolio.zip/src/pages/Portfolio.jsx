import Lista from "../assets/lista3.webp";
import pokemon from "../assets/pokemon.webp";

const Portfolio = () => {
  return (
    <div className="portfolio">
      <h2>PROJETOS</h2>
      {/* Projeto 1 */}
      <div className="project-card">
        <img src={pokemon} alt="Projeto 1" />
        <div className="project-details">
          <h2>POKEMON</h2>
          <p>
            Pokedex, aplicação que mostra todos os pokemons da primeira geração. Nesse
            site, além de você poder visualizar as imagens dos pokemons, poderá
            pesquisa-los através de seu nome ou id.
          </p>
          <a
            href="https://github.com/Eulet21/Pokedex.git"
            target="_blank"
            rel="noopener noreferrer"
          >
            Ver no GitHub
          </a>
        </div>
      </div>

      {/* Projeto 2 */}
      <div className="project-card">
        <img src={Lista} alt="Projeto 2" />
        <div className="project-details">
          <h2>LISTA</h2>
          <p>Aplicação básica que você pode fazer uma lista de tarefas.</p>
          <a
            href="https://github.com/Eulet21/Atividade.git"
            target="_blank"
            rel="noopener noreferrer"
          >
            Ver no GitHub
          </a>
        </div>
      </div>
    </div>
  );
};

export default Portfolio;
