import React from 'react';

const Footer = () => {
  return (
    <footer style={{ background: '#000000', color: '#fff', textAlign: 'center', padding: '1rem 0' }}>
      <p>© 2024 Meu Portfólio.</p>
    </footer>
  );
};

export default Footer;
